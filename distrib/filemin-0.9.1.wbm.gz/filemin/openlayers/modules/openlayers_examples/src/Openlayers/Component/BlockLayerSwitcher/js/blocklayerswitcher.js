Drupal.openlayers.pluginManager.register({
  fs: 'openlayers.component.internal.blocklayerswitcher',
  init: function(data) {}
});
