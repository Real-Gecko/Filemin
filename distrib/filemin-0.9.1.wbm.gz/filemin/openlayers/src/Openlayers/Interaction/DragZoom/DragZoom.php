<?php
/**
 * @file
 * Interaction: DragZoom.
 */

namespace Drupal\openlayers\Interaction;
use Drupal\openlayers\Types\Interaction;

$plugin = array(
  'class' => '\\Drupal\\openlayers\\Interaction\\DragZoom',
);

/**
 * Class DragZoom
 * @package Drupal\openlayers\Interaction
 */
class DragZoom extends Interaction {

}
