<?php
/**
 * @file
 * Interaction: KeyboardZoom.
 */

namespace Drupal\openlayers\Interaction;
use Drupal\openlayers\Types\Interaction;

$plugin = array(
  'class' => '\\Drupal\\openlayers\\Interaction\\KeyboardZoom',
);

/**
 * Class KeyboardZoom.
 */
class KeyboardZoom extends Interaction {

}
