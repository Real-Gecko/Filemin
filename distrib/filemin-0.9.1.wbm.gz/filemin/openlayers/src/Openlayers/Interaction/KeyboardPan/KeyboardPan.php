<?php
/**
 * @file
 * Interaction: KeyboardPan.
 */

namespace Drupal\openlayers\Interaction;
use Drupal\openlayers\Types\Interaction;

$plugin = array(
  'class' => '\\Drupal\\openlayers\\Interaction\\KeyboardPan',
);

/**
 * Class KeyboardPan.
 */
class KeyboardPan extends Interaction {

}
