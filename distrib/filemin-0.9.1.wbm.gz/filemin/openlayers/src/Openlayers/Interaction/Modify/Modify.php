<?php
/**
 * @file
 * Interaction: Modify.
 */

namespace Drupal\openlayers\Interaction;
use Drupal\openlayers\Types\Interaction;

$plugin = array(
  'class' => '\\Drupal\\openlayers\\Interaction\\Modify',
);

/**
 * Class Modify.
 */
class Modify extends Interaction {

}
