<?php
/**
 * @file
 * Interaction: Draw.
 */

namespace Drupal\openlayers\Interaction;
use Drupal\openlayers\Types\Interaction;

$plugin = array(
  'class' => '\\Drupal\\openlayers\\Interaction\\Draw',
);

/**
 * Class Draw.
 */
class Draw extends Interaction {

}
