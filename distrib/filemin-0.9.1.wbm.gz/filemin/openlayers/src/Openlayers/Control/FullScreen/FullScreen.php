<?php
/**
 * @file
 * Control: Fullscreen.
 */

namespace Drupal\openlayers\Control;
use Drupal\openlayers\Types\Control;

$plugin = array(
  'class' => '\\Drupal\\openlayers\\Control\\FullScreen',
);

/**
 * Class FullScreen.
 */
class FullScreen extends Control {

}
