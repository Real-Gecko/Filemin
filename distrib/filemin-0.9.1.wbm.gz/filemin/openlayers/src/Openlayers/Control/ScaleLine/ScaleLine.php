<?php
/**
 * @file
 * Control: ScaleLine.
 */

namespace Drupal\openlayers\Control;
use Drupal\openlayers\Types\Control;

$plugin = array(
  'class' => '\\Drupal\\openlayers\\Control\\ScaleLine',
);

/**
 * Class ScaleLine.
 */
class ScaleLine extends Control {

}
