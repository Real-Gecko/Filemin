<?php
/**
 * @file
 * Control: Zoom.
 */

namespace Drupal\openlayers\Control;
use Drupal\openlayers\Types\Control;

$plugin = array(
  'class' => '\\Drupal\\openlayers\\Control\\Zoom',
);

/**
 * Class Zoom.
 */
class Zoom extends Control {

}
