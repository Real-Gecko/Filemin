<?php
/**
 * @file
 * Source: ImageStatic.
 */

namespace Drupal\openlayers\Source;
use Drupal\openlayers\Types\Source;

$plugin = array(
  'class' => '\\Drupal\\openlayers\\Source\\ImageStatic',
);

/**
 * Class ImageStatic
 * @package Drupal\openlayers\Source
 */
class ImageStatic extends Source {

}
