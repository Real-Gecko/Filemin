<?php
/**
 * @file
 * Source: Vector.
 */

namespace Drupal\openlayers\Source;
use Drupal\openlayers\Types\Source;

$plugin = array(
  'class' => '\\Drupal\\openlayers\\Source\\Vector',
);

/**
 * Class Vector.
 */
class Vector extends Source {

}
