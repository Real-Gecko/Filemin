<?php
/**
 * @file
 * Class openlayers_component.
 */

namespace Drupal\openlayers\Types;

/**
 * Class openlayers_component.
 */
abstract class Component extends Object implements ComponentInterface {

}
