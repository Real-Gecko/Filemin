<?php
/**
 * @file
 * Class openlayers_projection.
 */

namespace Drupal\openlayers\Types;

/**
 * Class openlayers_projection.
 */
abstract class Projection extends Object implements ProjectionInterface {

}
