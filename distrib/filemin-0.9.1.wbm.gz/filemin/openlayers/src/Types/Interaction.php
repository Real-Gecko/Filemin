<?php
/**
 * @file
 * Class openlayers_interaction.
 */

namespace Drupal\openlayers\Types;

/**
 * Class openlayers_interaction.
 */
abstract class Interaction extends Object implements InteractionInterface {

}
