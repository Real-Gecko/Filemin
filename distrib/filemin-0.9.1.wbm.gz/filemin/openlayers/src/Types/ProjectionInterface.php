<?php
/**
 * @file
 * Interface openlayers_projection_interface.
 */

namespace Drupal\openlayers\Types;

/**
 * Interface openlayers_projection_interface.
 */
interface ProjectionInterface {

}
