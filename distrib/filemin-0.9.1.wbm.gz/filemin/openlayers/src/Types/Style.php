<?php
/**
 * @file
 * Class openlayers_style.
 */

namespace Drupal\openlayers\Types;

/**
 * Class openlayers_style.
 */
abstract class Style extends Object implements StyleInterface {

}
