<?php
/**
 * @file
 * Class openlayers_source.
 */

namespace Drupal\openlayers\Types;

/**
 * Class openlayers_source.
 */
abstract class Source extends Object implements SourceInterface {

}
