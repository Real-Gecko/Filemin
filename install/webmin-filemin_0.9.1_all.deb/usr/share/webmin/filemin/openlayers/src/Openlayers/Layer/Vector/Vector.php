<?php
/**
 * @file
 * Layer: Vector.
 */

namespace Drupal\openlayers\Layer;
use Drupal\openlayers\Types\Layer;

$plugin = array(
  'class' => '\\Drupal\\openlayers\\Layer\\Vector',
);

/**
 * Class Vector.
 */
class Vector extends Layer {

}
