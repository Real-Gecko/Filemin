<?php
/**
 * @file
 * Interaction: Select.
 */

namespace Drupal\openlayers\Interaction;
use Drupal\openlayers\Types\Interaction;

$plugin = array(
  'class' => '\\Drupal\\openlayers\\Interaction\\Select',
);

/**
 * Class Select.
 */
class Select extends Interaction {

}
