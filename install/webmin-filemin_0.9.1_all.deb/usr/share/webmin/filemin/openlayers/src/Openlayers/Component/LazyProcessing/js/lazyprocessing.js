Drupal.openlayers.pluginManager.register({
  fs: 'openlayers.component.internal.lazyprocessing',
  init: function(data) {
  }
});
