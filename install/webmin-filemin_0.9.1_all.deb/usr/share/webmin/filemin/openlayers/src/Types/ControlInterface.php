<?php
/**
 * @file
 * Interface openlayers_control_interface.
 */

namespace Drupal\openlayers\Types;

/**
 * Interface openlayers_control_interface.
 */
interface ControlInterface {

}
