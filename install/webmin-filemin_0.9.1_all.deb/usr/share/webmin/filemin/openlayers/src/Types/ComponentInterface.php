<?php
/**
 * @file
 * Interface openlayers_component_interface.
 */

namespace Drupal\openlayers\Types;

/**
 * Interface openlayers_component_interface.
 */
interface ComponentInterface {

}
