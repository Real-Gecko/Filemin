<?php
/**
 * @file
 * Control: ZoomSlider.
 */

namespace Drupal\openlayers\Control;
use Drupal\openlayers\Types\Control;

$plugin = array(
  'class' => '\\Drupal\\openlayers\\Control\\ZoomSlider',
);

/**
 * Class ZoomSlider.
 */
class ZoomSlider extends Control {

}
