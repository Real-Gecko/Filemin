<?php
/**
 * @file
 * Interface openlayers_style_interface.
 */

namespace Drupal\openlayers\Types;

/**
 * Interface openlayers_style_interface.
 */
interface StyleInterface {
}
