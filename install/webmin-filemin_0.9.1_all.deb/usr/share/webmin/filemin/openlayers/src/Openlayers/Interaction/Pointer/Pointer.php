<?php
/**
 * @file
 * Interaction: Pointer.
 */

namespace Drupal\openlayers\Interaction;
use Drupal\openlayers\Types\Interaction;

$plugin = array(
  'class' => '\\Drupal\\openlayers\\Interaction\\Pointer',
);

/**
 * Class Pointer.
 */
class Pointer extends Interaction {

}
