<?php
/**
 * @file
 * Interaction: DragRotateAndZoom.
 */

namespace Drupal\openlayers\Interaction;
use Drupal\openlayers\Types\Interaction;

$plugin = array(
  'class' => '\\Drupal\\openlayers\\Interaction\\DragRotateAndZoom',
);

/**
 * Class DragRotateAndZoom
 * @package Drupal\openlayers\Interaction
 */
class DragRotateAndZoom extends Interaction {

}
