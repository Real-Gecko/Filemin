<?php
/**
 * @file
 * Interaction: MouseWheelZoom.
 */

namespace Drupal\openlayers\Interaction;
use Drupal\openlayers\Types\Interaction;

$plugin = array(
  'class' => '\\Drupal\\openlayers\\Interaction\\MouseWheelZoom',
);

/**
 * Class MouseWheelZoom.
 */
class MouseWheelZoom extends Interaction {

}
