<?php
/**
 * @file
 * Class openlayers_control.
 */

namespace Drupal\openlayers\Types;

/**
 * Class openlayers_control.
 */
abstract class Control extends Object implements ControlInterface {

}
