<?php
/**
 * @file
 * Interface openlayers_source_interface.
 */

namespace Drupal\openlayers\Types;

/**
 * Interface openlayers_source_interface.
 */
interface SourceInterface {

}
