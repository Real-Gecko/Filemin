<?php
/**
 * @file
 * Interface openlayers_interaction_interface.
 */

namespace Drupal\openlayers\Types;

/**
 * Interface openlayers_interaction_interface.
 */
interface InteractionInterface {

}
