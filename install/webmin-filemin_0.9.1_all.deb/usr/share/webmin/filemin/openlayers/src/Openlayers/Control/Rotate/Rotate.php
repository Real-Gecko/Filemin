<?php
/**
 * @file
 * Control: Rotate.
 */

namespace Drupal\openlayers\Control;
use Drupal\openlayers\Types\Control;

$plugin = array(
  'class' => '\\Drupal\\openlayers\\Control\\Rotate',
);

/**
 * Class Rotate.
 */
class Rotate extends Control {

}
